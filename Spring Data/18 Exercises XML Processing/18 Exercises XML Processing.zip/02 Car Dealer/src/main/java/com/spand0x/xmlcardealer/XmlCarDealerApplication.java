package com.spand0x.xmlcardealer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlCarDealerApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlCarDealerApplication.class, args);
    }

}
