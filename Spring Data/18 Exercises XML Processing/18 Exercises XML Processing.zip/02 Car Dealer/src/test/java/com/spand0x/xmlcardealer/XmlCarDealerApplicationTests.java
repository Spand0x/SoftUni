package com.spand0x.xmlcardealer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlCarDealerApplicationTests {

    @Test
    void contextLoads() {
    }

}
