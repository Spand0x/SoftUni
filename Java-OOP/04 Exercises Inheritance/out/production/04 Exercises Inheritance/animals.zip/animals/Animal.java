package animals;

public abstract class Animal {
    private String name;
    private int age;
    private String gender;

    public Animal(String name, int age, String gender) {
        setName(name);
        setAge(age);
        setGender(gender);
    }

    private void setGender(String gender) {
        validateString(gender);
        this.gender = gender;
    }

    private void setName(String name) {
        validateString(name);
        this.name = name;
    }

    private void setAge(int age){
        if(age<0){
            throw new IllegalArgumentException();
        }else {
            this.age = age;
        }
    }

    private void validateString(String name) {
        if(name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException();
        }
    }

    private boolean checkAge(int age){
        return age>=0; //maybe without equals
    }

    public abstract String produceSound();


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return this.name + " " + this.age + " " + this.gender.toString();
    }
}
