package restaurant;

import java.math.BigDecimal;

public class Salmon extends MainDish {
    private final double SALMON_GRAMS;

    public Salmon(String name, BigDecimal price) {
        super(name, price, 22);
        this.SALMON_GRAMS = 22;
    }
}
