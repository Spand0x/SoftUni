package wildfarm.animals;

import wildfarm.food.Food;

public class Mouse extends Mammal {

    public Mouse(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight,  livingRegion);
    }

    @Override
    public String makeSound() {
        return "SQUEEEAAAK!";
    }

}
