package barrackswars.interfaces;

public interface Attacker {

    int getAttackDamage();
}
