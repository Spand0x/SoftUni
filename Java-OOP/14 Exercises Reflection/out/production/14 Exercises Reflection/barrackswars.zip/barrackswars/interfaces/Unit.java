package barrackswars.interfaces;


public interface Unit extends Destroyable, Attacker {
}