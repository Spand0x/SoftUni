package barrackswars.interfaces;


public interface Runnable {
    void run();
}
