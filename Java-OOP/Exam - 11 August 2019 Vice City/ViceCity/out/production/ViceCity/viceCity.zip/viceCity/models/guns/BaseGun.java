package viceCity.models.guns;

import static viceCity.common.ExceptionMessages.*;

public abstract class BaseGun implements Gun {
    private String name;
    private int bulletsPerBarrel;
    private int totalBullets;
    private int barrelCapacity;

    protected BaseGun(String name, int bulletsPerBarrel, int totalBullets) {
       setName(name);
       setBulletsPerBarrel(bulletsPerBarrel);
       setTotalBullets(totalBullets);
       this.barrelCapacity = bulletsPerBarrel;
    }

    protected void reload(){
            this.bulletsPerBarrel = barrelCapacity;
            this.totalBullets -= barrelCapacity;
    }

    private void setName(String name) {
        if(name == null || name.trim().isEmpty()){
            throw new NullPointerException(NAME_NULL);
        }
        this.name = name;
    }

    protected void setBulletsPerBarrel(int bulletsPerBarrel) {
        if (bulletsPerBarrel<0){
            throw new IllegalArgumentException(BULLETS_LESS_THAN_ZERO);
        }
        this.bulletsPerBarrel = bulletsPerBarrel;
    }

    private void setTotalBullets(int totalBullets) {
        if(totalBullets<0){
            throw new IllegalArgumentException(TOTAL_BULLETS_LESS_THAN_ZERO);
        }
        this.totalBullets = totalBullets;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getBulletsPerBarrel() {
        return bulletsPerBarrel;
    }

    @Override
    public int getTotalBullets() {
        return totalBullets;
    }

    @Override
    public boolean canFire() {
        if(this.bulletsPerBarrel<0 || this.totalBullets <0) {
            return false;
        }
        return true;
    }

}
