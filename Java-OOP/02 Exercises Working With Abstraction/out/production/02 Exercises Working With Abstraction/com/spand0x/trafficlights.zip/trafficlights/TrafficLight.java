package com.spand0x.trafficlights;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;
}
