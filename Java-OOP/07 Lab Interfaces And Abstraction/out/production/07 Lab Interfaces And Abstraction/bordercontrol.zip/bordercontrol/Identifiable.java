package bordercontrol;

public interface Identifiable {
    String getId();
}
