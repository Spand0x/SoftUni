package multipleimplementation;

public interface Birthable {
    String getBirthDate();
}
