package multipleimplementation;

public interface Person {
    String getName();
    int getAge();
}
