package telephony;

public interface Browsable {
   default String browse(){return "Browsing: ";};
}
