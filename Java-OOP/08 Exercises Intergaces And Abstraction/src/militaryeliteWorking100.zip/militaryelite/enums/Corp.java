package militaryelite.enums;

public enum Corp {
    Airforces,
    Marines,
}
