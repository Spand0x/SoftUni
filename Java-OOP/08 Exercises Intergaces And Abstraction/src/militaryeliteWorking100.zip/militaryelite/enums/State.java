package militaryelite.enums;

public enum State {
    inProgress,
    Finished,
}
