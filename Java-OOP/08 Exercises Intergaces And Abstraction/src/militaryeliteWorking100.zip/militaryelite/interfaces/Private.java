package militaryelite.interfaces;

public interface Private extends Soldier {
}
