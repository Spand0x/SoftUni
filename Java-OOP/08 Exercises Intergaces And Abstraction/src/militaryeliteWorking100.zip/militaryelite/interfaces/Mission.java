package militaryelite.interfaces;

import militaryelite.enums.State;

public interface Mission {
    String toString();
}
