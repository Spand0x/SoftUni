package militaryelite.interfaces;

public interface Spy {
}