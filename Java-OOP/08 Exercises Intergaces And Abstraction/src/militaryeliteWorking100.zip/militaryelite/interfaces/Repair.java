package militaryelite.interfaces;

public interface Repair {
    @Override
    public String toString();
}