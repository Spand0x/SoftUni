package militaryelite.interfaces;

import java.util.Collection;

public interface LeutenantGeneral {
    void addPrivate(Private priv);
}
