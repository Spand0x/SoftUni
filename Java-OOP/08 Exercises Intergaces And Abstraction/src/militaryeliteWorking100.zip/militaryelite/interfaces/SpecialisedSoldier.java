package militaryelite.interfaces;

public interface SpecialisedSoldier extends Soldier {
}