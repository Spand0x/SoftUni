package personbirthday;

public interface Identifiable {
    String getId();
}
