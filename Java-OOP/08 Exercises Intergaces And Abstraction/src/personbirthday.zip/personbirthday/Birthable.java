package personbirthday;

public interface Birthable {
    String getBirthDate();
}
