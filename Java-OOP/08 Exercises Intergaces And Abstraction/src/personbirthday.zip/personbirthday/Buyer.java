package personbirthday;

public interface Buyer {
    void buyFood();
    int getFood();
}
