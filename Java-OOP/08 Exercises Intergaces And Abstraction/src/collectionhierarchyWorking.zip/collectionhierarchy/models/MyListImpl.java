package collectionhierarchy.models;

import collectionhierarchy.interfaces.Removable;
import collectionhierarchy.interfaces.Addable;
import collectionhierarchy.interfaces.MyList;

public class MyListImpl extends Collection implements MyList, Addable, Removable {

    @Override
    public String remove() {
        return super.getItems().remove(0);
    }

    @Override
    public int add(String item) {
        super.getItems().add(0,item);
        return 0;
    }

    @Override
    public int used() {
        return super.getItems().size();
    }
}
