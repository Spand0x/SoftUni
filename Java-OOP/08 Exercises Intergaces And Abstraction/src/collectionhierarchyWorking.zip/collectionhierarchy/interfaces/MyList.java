package collectionhierarchy.interfaces;

public interface MyList {
    int used();
}
