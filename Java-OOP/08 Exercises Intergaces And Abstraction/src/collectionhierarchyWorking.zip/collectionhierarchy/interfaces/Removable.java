package collectionhierarchy.interfaces;

public interface Removable {
    String remove();
}
