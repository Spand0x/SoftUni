package collectionhierarchy.interfaces;

public interface Addable {
    int add(String string);
}
