package collectionhierarchy.interfaces;

public interface AddRemovable extends Addable{
    String remove();
}
