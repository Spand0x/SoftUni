package birthdaycelebrations;

public interface Birthable {
    String getBirthDate();
}
